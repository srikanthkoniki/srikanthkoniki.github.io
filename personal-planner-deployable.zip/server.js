require("dotenv").config();
const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_ME_IN_PRODUCTION";
const COOKIE_SECURE = process.env.COOKIE_SECURE === "true";

const db = new Database(process.env.DB_PATH || path.join(__dirname, "planner.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS monthly_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  month_key TEXT NOT NULL,
  plan TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, month_key),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS daily_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  date_key TEXT NOT NULL,
  goal TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, date_key),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  date_key TEXT NOT NULL,
  text TEXT NOT NULL,
  done INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
`);

app.use(express.json({limit:"1mb"}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

function tokenFor(user) {
  return jwt.sign({id:user.id, name:user.name, email:user.email}, JWT_SECRET, {expiresIn:"30d"});
}
function setAuth(res, user) {
  res.cookie("planner_token", tokenFor(user), {
    httpOnly:true, sameSite:"lax", secure:COOKIE_SECURE,
    maxAge:30*24*60*60*1000
  });
}
function auth(req,res,next) {
  try {
    const token=req.cookies.planner_token;
    if(!token) return res.status(401).json({error:"Not logged in"});
    req.user=jwt.verify(token, JWT_SECRET);
    next();
  } catch { res.status(401).json({error:"Session expired. Please log in again."}); }
}
function validDate(s){return /^\d{4}-\d{2}-\d{2}$/.test(s)}
function validMonth(s){return /^\d{4}-\d{2}$/.test(s)}

app.post("/api/auth/register",(req,res)=>{
  const {name,email,password}=req.body||{};
  if(!name||!email||!password) return res.status(400).json({error:"Name, email and password are required."});
  if(password.length<8) return res.status(400).json({error:"Password must be at least 8 characters."});
  const cleanEmail=String(email).trim().toLowerCase();
  try{
    const hash=bcrypt.hashSync(password,12);
    const info=db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(String(name).trim(),cleanEmail,hash);
    const user={id:info.lastInsertRowid,name:String(name).trim(),email:cleanEmail};
    setAuth(res,user); res.json({user});
  }catch(e){res.status(409).json({error:"An account with that email already exists."})}
});

app.post("/api/auth/login",(req,res)=>{
  const {email,password}=req.body||{};
  const user=db.prepare("SELECT * FROM users WHERE email=?").get(String(email||"").trim().toLowerCase());
  if(!user||!bcrypt.compareSync(password||"",user.password_hash)) return res.status(401).json({error:"Invalid email or password."});
  setAuth(res,user); res.json({user:{id:user.id,name:user.name,email:user.email}});
});
app.post("/api/auth/logout",(req,res)=>{res.clearCookie("planner_token");res.json({ok:true})});
app.get("/api/auth/me",auth,(req,res)=>res.json({user:req.user}));

app.get("/api/month/:month",auth,(req,res)=>{
  if(!validMonth(req.params.month)) return res.status(400).json({error:"Invalid month"});
  const row=db.prepare("SELECT plan FROM monthly_plans WHERE user_id=? AND month_key=?").get(req.user.id,req.params.month);
  res.json({plan:row?.plan||""});
});
app.put("/api/month/:month",auth,(req,res)=>{
  if(!validMonth(req.params.month)) return res.status(400).json({error:"Invalid month"});
  const plan=String(req.body.plan||"");
  db.prepare(`INSERT INTO monthly_plans(user_id,month_key,plan) VALUES(?,?,?)
    ON CONFLICT(user_id,month_key) DO UPDATE SET plan=excluded.plan,updated_at=CURRENT_TIMESTAMP`)
    .run(req.user.id,req.params.month,plan);
  res.json({ok:true});
});

app.get("/api/day/:date",auth,(req,res)=>{
  if(!validDate(req.params.date)) return res.status(400).json({error:"Invalid date"});
  const entry=db.prepare("SELECT goal,notes FROM daily_entries WHERE user_id=? AND date_key=?").get(req.user.id,req.params.date);
  const tasks=db.prepare("SELECT id,text,done FROM tasks WHERE user_id=? AND date_key=? ORDER BY id").all(req.user.id,req.params.date);
  res.json({goal:entry?.goal||"",notes:entry?.notes||"",tasks});
});
app.put("/api/day/:date",auth,(req,res)=>{
  if(!validDate(req.params.date)) return res.status(400).json({error:"Invalid date"});
  const goal=String(req.body.goal||""),notes=String(req.body.notes||"");
  db.prepare(`INSERT INTO daily_entries(user_id,date_key,goal,notes) VALUES(?,?,?,?)
    ON CONFLICT(user_id,date_key) DO UPDATE SET goal=excluded.goal,notes=excluded.notes,updated_at=CURRENT_TIMESTAMP`)
    .run(req.user.id,req.params.date,goal,notes);
  res.json({ok:true});
});
app.post("/api/day/:date/tasks",auth,(req,res)=>{
  if(!validDate(req.params.date)) return res.status(400).json({error:"Invalid date"});
  const text=String(req.body.text||"").trim(); if(!text)return res.status(400).json({error:"Task is required"});
  const info=db.prepare("INSERT INTO tasks(user_id,date_key,text) VALUES(?,?,?)").run(req.user.id,req.params.date,text);
  res.json({id:info.lastInsertRowid,text,done:0});
});
app.patch("/api/tasks/:id",auth,(req,res)=>{
  const task=db.prepare("SELECT * FROM tasks WHERE id=? AND user_id=?").get(req.params.id,req.user.id);
  if(!task)return res.status(404).json({error:"Task not found"});
  db.prepare("UPDATE tasks SET done=? WHERE id=? AND user_id=?").run(req.body.done?1:0,req.params.id,req.user.id);
  res.json({ok:true});
});
app.delete("/api/tasks/:id",auth,(req,res)=>{
  db.prepare("DELETE FROM tasks WHERE id=? AND user_id=?").run(req.params.id,req.user.id);res.json({ok:true});
});

app.get("/api/calendar/:month",auth,(req,res)=>{
  if(!validMonth(req.params.month))return res.status(400).json({error:"Invalid month"});
  const rows=db.prepare(`SELECT d.date_key,
      CASE WHEN d.goal<>'' OR d.notes<>'' THEN 1 ELSE 0 END AS has_entry,
      (SELECT COUNT(*) FROM tasks t WHERE t.user_id=d.user_id AND t.date_key=d.date_key) task_count,
      (SELECT COUNT(*) FROM tasks t WHERE t.user_id=d.user_id AND t.date_key=d.date_key AND t.done=1) done_count
      FROM daily_entries d WHERE d.user_id=? AND d.date_key LIKE ? || '-%'`).all(req.user.id,req.params.month);
  const tasks=db.prepare(`SELECT date_key,COUNT(*) task_count,SUM(done) done_count FROM tasks
    WHERE user_id=? AND date_key LIKE ? || '-%' GROUP BY date_key`).all(req.user.id,req.params.month);
  const map={}; rows.forEach(r=>map[r.date_key]=r); tasks.forEach(r=>{map[r.date_key]=Object.assign(map[r.date_key]||{},r)});
  res.json(map);
});

app.listen(PORT,()=>console.log(`Personal Planner running at http://localhost:${PORT}`));
