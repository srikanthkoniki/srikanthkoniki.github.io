# My Personal Planner — deployable web app

A responsive personal planner with:
- Secure login/signup using hashed passwords
- HTTP-only authentication cookie
- Per-user monthly plans
- Per-user day-wise goals and notes
- Per-user tasks with completion status
- SQLite database
- Works on desktop and mobile browsers
- No frontend framework required

## 1. Requirements

Install Node.js 20+.

## 2. Run locally

```bash
npm install
copy .env.example .env
```

On macOS/Linux use:

```bash
cp .env.example .env
```

Edit `.env` and set a strong `JWT_SECRET`.

Then:

```bash
npm start
```

Open `http://localhost:3000`.

## 3. Deploy

This is a normal Node/Express application. Deploy it to a Node-compatible host.

Set these environment variables on the host:

- `PORT` — supplied by many hosts automatically
- `JWT_SECRET` — long random secret
- `COOKIE_SECURE=true` — use this when the site is served over HTTPS
- `DB_PATH` — optional path for the SQLite database

### Important for cloud deployment

SQLite is appropriate for a single persistent server or a host with persistent disk. If your hosting platform uses an ephemeral filesystem, the database can be lost on redeploy/restart. For a production multi-instance deployment, replace SQLite with PostgreSQL (the API structure is already separated to make that migration straightforward).

## 4. Security notes

- Never commit `.env` or the real JWT secret.
- Always use HTTPS in production.
- Passwords are hashed with bcrypt.
- Authentication is stored in an HTTP-only cookie.
- Each database query is scoped to the logged-in user.

## 5. Suggested next upgrades

- Password reset by email
- Google/Apple sign-in
- Cloud PostgreSQL
- Recurring tasks
- Reminders/notifications
- Attachments
- Search and reports
- PWA install/offline support
- Export to PDF/Excel
