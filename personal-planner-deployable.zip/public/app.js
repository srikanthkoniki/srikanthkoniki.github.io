let user=null, view=new Date(), selected=new Date();
view=new Date(view.getFullYear(),view.getMonth(),1);
const $=id=>document.getElementById(id);
const pad=n=>String(n).padStart(2,"0");
const dateKey=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const monthKey=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}`;
const pretty=d=>d.toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"});
async function api(url,opts={}){const r=await fetch(url,{headers:{"Content-Type":"application/json",...(opts.headers||{})},...opts});let data={};try{data=await r.json()}catch{}if(!r.ok)throw new Error(data.error||"Request failed");return data}

let mode="login";
$("loginTab").onclick=()=>setMode("login");$("registerTab").onclick=()=>setMode("register");
function setMode(m){mode=m;$("loginTab").classList.toggle("active",m==="login");$("registerTab").classList.toggle("active",m==="register");$("nameWrap").classList.toggle("hidden",m==="login");$("authBtn").textContent=m==="login"?"Login":"Create account";$("authMsg").textContent="";$("password").autocomplete=m==="login"?"current-password":"new-password"}
$("authForm").onsubmit=async e=>{e.preventDefault();$("authMsg").textContent="";try{let data=await api("/api/auth/"+mode,{method:"POST",body:JSON.stringify({name:$("name").value,email:$("email").value,password:$("password").value})});user=data.user;showApp()}catch(err){$("authMsg").textContent=err.message}};
$("logout").onclick=async()=>{await api("/api/auth/logout",{method:"POST"});location.reload()};

async function showApp(){ $("authView").classList.add("hidden");$("appView").classList.remove("hidden");$("welcome").textContent="Hi, "+user.name; await renderAll()}
async function renderAll(){await renderCalendar();await loadDay();await loadMonth()}
async function renderCalendar(){
 $("calTitle").textContent=view.toLocaleDateString(undefined,{month:"long",year:"numeric"});$("monthStat").textContent=view.toLocaleDateString(undefined,{month:"long",year:"numeric"});
 const map=await api("/api/calendar/"+monthKey(view));const c=$("calendar");c.innerHTML="";
 ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].forEach(x=>c.innerHTML+=`<div class="weekday">${x}</div>`);
 const first=new Date(view.getFullYear(),view.getMonth(),1).getDay(),days=new Date(view.getFullYear(),view.getMonth()+1,0).getDate();
 for(let i=0;i<first;i++)c.innerHTML+="<div></div>";
 for(let n=1;n<=days;n++){const d=new Date(view.getFullYear(),view.getMonth(),n),k=dateKey(d),m=map[k]||{};let cls="day";if(k===dateKey(selected))cls+=" selected";if(k===dateKey(new Date()))cls+=" today";
 let marks=(m.task_count?`<span class="dot"></span>${m.done_count||0}/${m.task_count}`:"")+(m.has_entry?"<br>📝 Entry":"");
 c.innerHTML+=`<div class="${cls}" data-date="${k}"><div class="daynum">${n}</div><div class="marks">${marks}</div></div>`}
 c.querySelectorAll(".day").forEach(el=>el.onclick=async()=>{selected=new Date(el.dataset.date+"T00:00:00");await loadDay();await renderCalendar()})
}
async function loadDay(){const k=dateKey(selected),d=await api("/api/day/"+k);$("dayTitle").textContent="Day-wise Entry — "+pretty(selected);$("dateStat").textContent=pretty(selected);$("goal").value=d.goal;$("notes").value=d.notes;renderTasks(d.tasks);updateStats(d.tasks)}
function renderTasks(tasks){$("tasks").innerHTML=tasks.length?tasks.map(t=>`<div class="task"><input type="checkbox" ${t.done?"checked":""} data-id="${t.id}" class="toggle"><span class="${t.done?"done":""}">${esc(t.text)}</span><button class="delete" data-del="${t.id}">×</button></div>`).join(""):'<p class="muted">No tasks yet.</p>';
 document.querySelectorAll(".toggle").forEach(x=>x.onchange=async()=>{await api("/api/tasks/"+x.dataset.id,{method:"PATCH",body:JSON.stringify({done:x.checked})});await loadDay();await renderCalendar()});
 document.querySelectorAll("[data-del]").forEach(x=>x.onclick=async()=>{await api("/api/tasks/"+x.dataset.del,{method:"DELETE"});await loadDay();await renderCalendar()})
}
function updateStats(ts){$("taskStat").textContent=ts.length;$("doneStat").textContent=ts.filter(t=>t.done).length}
$("saveDay").onclick=async()=>{await api("/api/day/"+dateKey(selected),{method:"PUT",body:JSON.stringify({goal:$("goal").value,notes:$("notes").value})});await renderCalendar();flash($("saveDay"))};
$("addTask").onclick=addTask;$("taskInput").onkeydown=e=>{if(e.key==="Enter")addTask()};
async function addTask(){const v=$("taskInput").value.trim();if(!v)return;await api("/api/day/"+dateKey(selected)+"/tasks",{method:"POST",body:JSON.stringify({text:v})});$("taskInput").value="";await loadDay();await renderCalendar()}
async function loadMonth(){const d=await api("/api/month/"+monthKey(view));$("monthlyPlan").value=d.plan;$("planMonth").textContent=view.toLocaleDateString(undefined,{month:"long",year:"numeric"})}
$("saveMonth").onclick=async()=>{await api("/api/month/"+monthKey(view),{method:"PUT",body:JSON.stringify({plan:$("monthlyPlan").value})});flash($("saveMonth"))};
$("prev").onclick=async()=>{view=new Date(view.getFullYear(),view.getMonth()-1,1);selected=new Date(view.getFullYear(),view.getMonth(),1);await renderAll()};
$("next").onclick=async()=>{view=new Date(view.getFullYear(),view.getMonth()+1,1);selected=new Date(view.getFullYear(),view.getMonth(),1);await renderAll()};
function flash(btn){const old=btn.textContent;btn.textContent="Saved ✓";setTimeout(()=>btn.textContent=old,1200)}
function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
setInterval(()=>{$("clock").textContent=new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})},1000);
(async()=>{try{const d=await api("/api/auth/me");user=d.user;showApp()}catch{}})();
